# Paidit
A stress free way to calculate and know the future of your loans.
[https://finance-website-235401.appspot.com/](https://finance-website-235401.appspot.com/)

Submission for MLH Cypher Hacks 2019

Paid it is a college loan calculator and website advisor for your college loans. Input your loan data and your earnings and receive a month by month payment plan for your college loans. Along with advice on loan payment plans.

---

#### Technology:
**Front End:** HTML5, Javascript, css

**Back End:** Nodejs, Express, Google SDK


---
